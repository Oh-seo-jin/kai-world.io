#include "stack.h"
#define MAX_CAPACITY 100

int stack[MAX_CAPACITY];
int top = -1;

int is_empty() {
	return top == -1;
}

int is_full() {
	return top == MAX_CAPACITY - 1;
}

void push(int i) {
	if (is_full()) {
		printf("stack is full.\n");
		return;
	}
	top++;
	stack[top] = i;
}

int pop() {
	if (is_empty()) {
		printf("stack is empty.\n");
		return -1;
	}
	char tmp = stack[top];
	top--;
	return tmp;
}

int peek() {
	return stack[top];
}
