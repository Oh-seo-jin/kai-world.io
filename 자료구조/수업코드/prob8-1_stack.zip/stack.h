#ifndef STACK_H
#define STACK_H
#include <stdio.h>

void push(int i);
int pop();
int peek();
int is_empty();
int is_full();

#endif