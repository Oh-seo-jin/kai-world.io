#ifndef LIBRARY_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define LIBRARY_H

//����ü ��ȯ����
typedef struct song Song;
typedef struct snode SNode;
typedef struct artist Artist;


struct song {
	Artist* artist;
	char* title;
	char* path;
	int index;
};

struct snode {
	SNode* next, * prev;
	Song *song;
};

struct artist {
	char* name;
	Artist* next;
	SNode* head, *tail;
};

void initialize();
void load(FILE* fp);
void add_song(char* artist, char* title, char* path);
void status();
void search_song(char* artist);
void search_song(char* artist, char* title);
void play(int index);
void save(FILE* fp);
void remove(int index);

#endif