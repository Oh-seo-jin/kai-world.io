//�׽�Ʈ ���
#include "queueADT.h"
#include "pos.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#pragma warning (disable:4996)

#define BACKGRAUND 0
#define IMAGE 1
#define INIT_VISIT -1

int n, T;
int img[MAX][MAX];

void read_img(FILE* fp);
void print_img();
bool movable(Position pos, int dir);
void clear_array();
Position find_start();

int main() {

	FILE* fp = fopen("input.txt", "r");
	fscanf(fp, "%d", &T);
	Queue queue = create();

	for (int i = 0; i < T; i++) {

		clear_array();
		read_img(fp);
		make_empty(queue);

		Position init = find_start();
		enqueue(queue, init);
		img[init.x][init.y] = INIT_VISIT;
		int component_size = 1;

		//print_img();

		while (1) {
			Position cur = dequeue(queue);
			//printf("cur: (%d, %d)\n", cur.x, cur.y);

			for (int dir = 0; dir < 8; dir++) {
				if (moveable(cur, dir)) {
					component_size++;
					Position p = move_to(cur, dir);
					img[p.x][p.y] = img[cur.x][cur.y] - 1;
					//printf("->[%d]cur: (%d, %d)\n", dir, cur.x, cur.y);
					enqueue(queue, p);
				}
			}

			//End of component
			if (is_empty(queue)) {
				printf("%d ", component_size);

				//printf("====restart====\n");
				cur = find_start();
				img[cur.x][cur.y] = INIT_VISIT;
				make_empty(queue);
				enqueue(queue, cur);
				if (cur.x < 0) {
					//printf("\n%d��° �̹��� �Ϸ�\n", i+1);
					//print_img();
					printf("\n");
					break;
				}
				component_size = 1;			
			}
		}

	}
	fclose(fp);

}


void read_img(FILE* fp) {
	fscanf(fp, "%d", &n);
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			fscanf(fp, "%d", &img[i][j]);
		}
	}
	//print_img();
}

void print_img() {
	printf("----------\n");
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			printf("%4d", img[i][j]);
		}
		printf("\n");
	}
}


bool moveable(Position cur, int dir) {
	if (cur.x + offset[dir][0] < 0
		|| cur.y + offset[dir][1] < 0
		|| cur.x + offset[dir][0] >= n
		|| cur.y + offset[dir][1] >= n)
		return false;
	//printf("img[%d][%d] = %d\n", cur.x + offset[dir][0], cur.y + offset[dir][1], img[cur.x + offset[dir][0]][cur.y + offset[dir][1]]);
	if (img[cur.x + offset[dir][0]][cur.y + offset[dir][1]] == IMAGE)
		return true;
	return false;
}

void clear_array() {
	img[MAX][MAX] = { 0 };
	//print_img();
}

Position find_start() {
	Position p;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			if (img[i][j] == IMAGE) {
				p.x = i;
				p.y = j;
				//printf("start at (%d, %d)\n", i, j);
				return p;
			}
		}
	}
	p.x = -1;
	p.y = -1;
	return p;
}