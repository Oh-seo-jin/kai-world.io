#include <stdio.h>
#include <string.h>
#include "stackADT.h"
#pragma warning (disable:4996)
#define BUFFER_SIZE 100

int read_line(FILE* fp, char str[], int n) {
	int ch, i = 0;

	while ((ch = fgetc(fp)) != '\n' && ch != EOF) {
		if (i < n)
			str[i++] = ch;
	}
	str[i] = '\0';
	return i;
}
void handle_command();
void handle_create(char* name);
void handle_push(char* name, char* str);
void handle_list(char* name);
void handle_pop(char* name);

int main() {
	handle_command();
	return 0;
}

void handle_command() {
	char buffer[BUFFER_SIZE];
	char* command, * name, * str;

	while (1) {
		printf("$ ");
		if (read_line(stdin, buffer, BUFFER_SIZE) < 0)
			return;
		command = strtok(buffer, " ");
		if (strcmp(command, "create") == 0) {
			name = strtok(NULL, " ");
			handle_create(name);
		}
		else if (strcmp(command, "push") == 0) {
			name = strtok(NULL, " ");
			str = strtok(NULL, " ");
			handle_push(name, str);
		}
		else if (strcmp(command, "list") == 0) {
			name = strtok(NULL, " ");
			handle_list(name);
		}
		else if (strcmp(command, "pop") == 0) {
			name = strtok(NULL, " ");
			handle_pop(name);
		}
		else if (strcmp(command, "exit") == 0) {
			break;
		}
	}
}

void handle_create(char* name) {
	create(name);
}

void handle_push(char* name, char* str) {
	int i = find_stack_list(name);
	push(stack_list[i], str);
}

void handle_list(char* name) {
	int i = find_stack_list(name);
	list(stack_list[i]);
}

void handle_pop(char* name) {
	int i = find_stack_list(name);
	printf("%s\n", pop(stack_list[i]));
}