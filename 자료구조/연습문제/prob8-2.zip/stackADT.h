#ifndef STACKADT_H
#define STACKADT_H

#include <stdbool.h>
#define LIST_MAX 10

typedef char* Item;

typedef struct stack_type* Stack;
extern Stack stack_list[LIST_MAX];

void add_to_list(Stack s);
int find_stack_list(char* name);
void create(char* name);
void destroy(Stack s);
void make_empty(Stack s);
bool is_full(Stack s);
bool is_empty(Stack s);
void push(Stack s, Item i);
Item pop(Stack s);
Item peek(Stack s);
void reallocate(Stack s);
void list(Stack s);

#endif