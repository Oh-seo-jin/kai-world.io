//�׽�Ʈ ���
#include "stackADT.h"
#include "pos.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#pragma warning (disable:4996)
#define MAX 50
#define BACKGRAUND 0
#define IMAGE 1
#define VISITED 2
#define BACKTRACKED 3

//�迭�� ���� ��� �ʱ�ȭ

int n, T;
int img[MAX][MAX];

void read_img(FILE* fp);
void print_img();
bool movable(Position pos, int dir);
void clear_array();
Position find_start();

int main() {

	FILE* fp = fopen("input.txt", "r");
	fscanf(fp, "%d", &T);
	Stack s = create();

	//Position init_pos;	//������ġ �ʱ�ȭ��
	//init_pos.x = 0;
	//init_pos.y = 0;

	for (int i = 0; i < T; i++) {

		clear_array();
		read_img(fp);
		make_empty(s);

		Position init_position = find_start();
		Position cur = init_position;
		int init_dir = 0;
		bool component = true;
		int component_size = 1;

		while (1) {

			img[cur.x][cur.y] = VISITED;
			//printf("cur: (%d, %d)", cur.x, cur.y);

			bool forwarded = false;
			for (int dir = init_dir; dir < 8; dir++) {
				if (moveable(cur, dir)) {
					component_size++;
					push(s, dir);
					cur = move_to(cur, dir);
					//printf("->[%d]cur: (%d, %d)\n", dir, cur.x, cur.y);
					forwarded = true;
					init_dir = 0;
					break;
				}
			}

			if (!forwarded) {
				img[cur.x][cur.y] = BACKTRACKED;
				if (is_empty(s)) {
					//printf("[%d]image: %d\n", i+1, component_size);
					//printf("End one component.\n");
					//print_img();
					printf("%d ", component_size);
					component = false;
				}
				else {
					int d = pop(s);
					cur = move_to(cur, (d + 4) % 8);
					//printf("\n");
					init_dir = d + 1;
				}
			}

			//restart
			if (!component) {
				//printf("====restart====\n");
				init_position = find_start();
				if (init_position.x < 0) {
					//printf("%d��° �̹��� �Ϸ�\n", i+1);
					printf("\n");
					//print_img();
					break;
				}
				cur = init_position;
				component = true;
				component_size = 1;
				init_dir = 0;
				make_empty(s);
			}
		}

	}
	fclose(fp);

}


void read_img(FILE* fp) {
	fscanf(fp, "%d", &n);
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			fscanf(fp, "%d", &img[i][j]);
		}
	}
	//print_img();
}

void print_img() {
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			printf("%d", img[i][j]);
		}
		printf("\n");
	}
}


bool moveable(Position cur, int dir) {
	if (cur.x + offset[dir][0] < 0
		|| cur.y + offset[dir][1] < 0
		|| cur.x + offset[dir][0] >= n
		|| cur.y + offset[dir][1] >= n)
		return false;
	//printf("img[%d][%d] = %d\n", cur.x + offset[dir][0], cur.y + offset[dir][1], img[cur.x + offset[dir][0]][cur.y + offset[dir][1]]);
	if (img[cur.x + offset[dir][0]][cur.y + offset[dir][1]] == IMAGE)
		return true;
	return false;
}

void clear_array() {
	img[MAX][MAX] = { 0 };
	//print_img();
}

Position find_start() {
	Position p;
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			if (img[i][j] == IMAGE) {
				p.x = i;
				p.y = j;
				//printf("start at (%d, %d)\n", i, j);
				return p;
			}
		}
	}
	p.x = -1;
	p.y = -1;
	return p;
}