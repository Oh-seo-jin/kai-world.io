#include <stdio.h>
#include <string.h>
#include <time.h>
#include "stack08_3.h"
#pragma warning (disable:4996)
#define N_MAX 1000000
#define T_MAX 1000000

int T, N;

void load();
void handle_push(FILE* fp, int N);


int main() {
	time_t start, end;
	start = time(NULL);

	load();

	end = time(NULL);
	double result = (double)(end - start);
	printf("Elapsed Time: %f", result);
	return 0;
}

void load() {
	FILE* fp = fopen("input.txt", "r");
	fscanf(fp, "%d", &T);
	T = 9;
	int read_test_case = T;
	while (read_test_case > 0) {
		fscanf(fp, "%d", &N);
		//stack �ʱ�ȭ
		make_empty();
		//printf("%d��° test : %d���� ����\n", read_test_case+1, N);

		handle_push(fp, N);
		read_test_case--;
	}
	fclose(fp);
}

void handle_push(FILE* fp, int N) {

	int result = 0;

	int read_int = N;
	while (read_int > 0) {
		int buf;
		fscanf(fp, "%d", &buf);
		push(buf);
		//printf("%d is pushed,\n", buf);
		read_int--;
	}
	
	//list();

	int calc_case = N;
	while (calc_case > 0) {
		int target = pop();
		//printf("%d is poped.\n", target);
		result += handle_h(target);
		calc_case--;
	}
	result %= 1000000;
	printf("result: %d\n", result);
}