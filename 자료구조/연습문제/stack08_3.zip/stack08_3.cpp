//�迭
#include <stdio.h>
#include <stdlib.h>
#include "stack08_3.h"
#define MAX_CAPACITY 1000000

Item stack[MAX_CAPACITY];
int top = -1;

static void terminate(const char* message) {
	printf("%s\n", message);
	exit(1);
}

//Stack create() {
//	Stack s = (Stack)malloc(sizeof(struct stack_type));
//	if (s == NULL)
//		terminate("Error in create: stack could not be created.\n");
//	s->contents = (Item*)malloc(INIT_CAPACITY * sizeof(Item));
//	if (s->contents == NULL) {
//		free(s);
//		terminate("Error in create: stack could not be created.\n");
//	}
//	s->top = -1;
//	s->size = INIT_CAPACITY;
//	return s;
//}

////���� ����
//void destroy(Stack s) {
//	free(s->contents);
//	free(s);
//}

//���� ����
void make_empty() {
	top = -1;
}

bool is_full() {
	return top == MAX_CAPACITY;
}

bool is_empty() {
	return top == -1;
}

void push(Item i) {
	if (is_full())
		terminate("Error in push: stack is full.\n");
	top++;
	stack[top] = i;
}

Item pop() {
	if (is_empty())
		terminate("Error in pop: stack is empty.\n");
	top--;
	return stack[top + 1];
}

Item peek() {
	if (is_empty())
		terminate("Error in pop: stack is empty.\n");
	return stack[top];
}

//void reallocate(Stack s) {
//	Item* tmp = (Item*)malloc(2 * s->size * sizeof(Item));
//	if (tmp == NULL)
//		terminate("Error in create: stack could not be created.\n");
//	for (int i = 0; i < s->size; i++)
//		tmp[i] = s->contents[i];
//	free(s->contents);
//	s->contents = tmp;
//	s->size *= 2;
//}

int handle_h(int target) {
	int result = 0;

	for (int i = top; i >= 0 && stack[i] <= target; i--) {
		result++;
	}
	//printf("h(a[%d]) = %d\n", target, result);
	return result;
}

void list() {
	int i = top;
	while (i >= 0) {
		printf("%d\n", stack[i]);
		i--;
	}
}