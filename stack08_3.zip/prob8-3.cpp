#include <stdio.h>
#include <string.h>
#include "stackADT.h"
#pragma warning (disable:4996)
#define N_MAX 100
#define T_MAX 100

int T, N[N_MAX];
Stack s[T_MAX];

void load();
void sum_h();


int main() {

	load();
	sum_h();

	return 0;
}

void load() {
	FILE* fp = fopen("test.txt", "r");
	fscanf(fp, "%d", &T);
	int read_test_case = 0;
	while (read_test_case < T) {
		fscanf(fp, "%d", N+read_test_case);
		printf("%d��° test : %d���� ����\n", read_test_case+1, N[read_test_case]);
		s[read_test_case] = create();

		int read_int = N[read_test_case];
		while (read_int > 0) {
			int buf;
			fscanf(fp, "%d", &buf);
			push(s[read_test_case], buf);
			printf("%d is pushed,\n", buf);
			read_int--;
		}
		read_test_case++;
	}
	fclose(fp);
}

void sum_h() {
	int test_case = 0;
	while (test_case < T) {
		int result = 0;
		int calc_case = N[test_case];

		while (calc_case > 0) {
			int target = pop(s[test_case]);
			printf("%d is poped.\n", target);
			result += handle_h(s[test_case], target);
			calc_case--;
		}
		printf("result: %d\n", result);
		test_case++;
	}

}
